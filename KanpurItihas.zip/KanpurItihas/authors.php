<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />

    <title>All India History Compilation Scheme Kanpur Bundelkhand</title>
    <meta content="" name="description" />
    <meta content="" name="keywords" />

    <!-- Favicons -->
    <link href="assets/img/logo/logo1.png" rel="icon" />
    <link href="assets/img/logo/logo1.png" rel="apple-touch-icon" />

    <!-- Google Fonts -->
    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
      rel="stylesheet"
    />

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet" />
    <link
      href="assets/vendor/bootstrap/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="assets/vendor/bootstrap-icons/bootstrap-icons.css"
      rel="stylesheet"
    />
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet" />
    <link
      href="assets/vendor/glightbox/css/glightbox.min.css"
      rel="stylesheet"
    />
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet" />

    <!-- =======================================================
  * Template Name:Crawinx
  * Updated: Sep 30 2023 with Bootstrap v5.3.2
  * Author: Crawinx.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  </head>

  <body>
    <!-- ======= Top Bar ======= -->
    <section class="d-flex align-items-center">
      <div class="container-fluid d-flex justify-content-center">
        <div class="header-left me-4">
          <a href="index.php"
            ><img
              src="assets/img/logo/logo1.png"
              style="width: 80px; height: 80px"
              alt="Logo"
          /></a>
        </div>
        <div class="header-right">
          <div class="d-flex flex-column justify-content-center">
            <p class="fs-3 fw-bolder" style="font-size: 60px">
              All India History Compilation Scheme Kanpur Bundelkhand
            </p>
            <p style="font-size: 30px">
              अखिल भारतीय इतिहास संकलन योजना कानपुर, बुन्देलखण्ड
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center">
      <div class="container d-flex align-items-center">
        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
            <li><a class="nav-link scrollto" href="#about">About</a></li>
            <li><a class="nav-link scrollto" href="#journal">Journal</a></li>
            <li>
              <a class="nav-link scrollto" href="#portfolio">Portfolio</a>
            </li>
            <li>
              <a class="nav-link" href="managingcommitee.php">Managing Committee</a>
            </li>
            <li class="dropdown">
              <a href="#"
                ><span>Journal</span> <i class="bi bi-chevron-down"></i
              ></a>
              <ul>
               <!-- <li><a href="#">Journal</a></li>
                 <li class="dropdown">
                  <a href="journal.php"
                    ><span>Deep Drop Down</span>
                    <i class="bi bi-chevron-right" style="background-color:blue;"></i
                  ></a>
                  <ul>
                    <li><a href="#">Deep Drop Down 1</a></li>
                    <li><a href="#">Deep Drop Down 2</a></li>
                  </ul>
                </li> -->
                <li><a href="journal.php">About the Journal</a></li>
                <li><a href="editorial.php">Editorial Board</a></li>
                <li><a href="authors.php">For Authors</a></li>
                <li><a href="ethicdiscc.php">Ethisc Discussion</a></li>
                <li><a href="allvolume.php">All Volume & Issues</a></li>
              </ul>
            </li>
            <li><a class="nav-link scrollto" href="#team">Team</a></li>
            
            <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
        <!-- .navbar -->
      </div>
    </header>
    <!-- End Header -->







    <!-- ======= Footer ======= -->
    <footer id="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <div class="footer-logo">
                  <h5><span>All India History Compilation Scheme Kanpur Bundelkhand</span></h5>
                </div>
                <p>All India History Compilation Scheme is a nationwide organization of scholars working in the field of History,
                  Archaeology, Indology, Numismatics, Epigraphy, Law, modernity, Hindutva and other allied disciplines. 
                </p>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>Links</h4>
                <li><a href="#about">About</a></li>
                <li><a href="journal.html">Journal</a></li>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>Contact</h4>
                <div class="footer-contacts">
                  <p><span>Tel:</span> +123 456 789</p>
                  <p><span>Email:</span> contact@example.com</p>
                  <p><span>Working Hours:</span> 9am-5pm</p>
                </div>
              </div>
            </div>
          </div>
        <div class="social-links">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
        <div class="copyright">
          &copy; Copyright <strong><span>All India History Compilation Scheme Kanpur Bundelkhand </span>2023</strong>. All Rights Reserved
        </div>
      </div>
    </footer>
    <!-- End Footer -->

    <a
      href="#"
      class="back-to-top d-flex align-items-center justify-content-center"
      ><i class="bi bi-arrow-up-short"></i
    ></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
  </body>
</html>