<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />

    <title>All India History Compilation Scheme Kanpur Bundelkhand</title>
    <meta content="" name="description" />
    <meta content="" name="keywords" />

    <!-- Favicons -->
    <link href="assets/img/logo/logo1.png" rel="icon" />
    <link href="assets/img/logo/logo1.png" rel="apple-touch-icon" />

    <!-- Google Fonts -->
    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
      rel="stylesheet"
    />

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet" />
    <link
      href="assets/vendor/bootstrap/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="assets/vendor/bootstrap-icons/bootstrap-icons.css"
      rel="stylesheet"
    />
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet" />
    <link
      href="assets/vendor/glightbox/css/glightbox.min.css"
      rel="stylesheet"
    />
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet" />

    <!-- =======================================================
  * Template Name:Crawinx
  * Updated: Sep 30 2023 with Bootstrap v5.3.2
  * Author: Crawinx.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  </head>

  <body>
    <!-- ======= Top Bar ======= -->
    <section class="d-flex align-items-center">
      <div class="container-fluid d-flex justify-content-center">
        <div class="header-left me-4">
          <a href="index.php"
            ><img
              src="assets/img/logo/logo1.png"
              style="width: 80px; height: 80px"
              alt="Logo"
          /></a>
        </div>
        <div class="header-right">
          <div class="d-flex flex-column justify-content-center">
            <p class="fs-3 fw-bolder" style="font-size: 60px">
              All India History Compilation Scheme Kanpur Bundelkhand
            </p>
            <p style="font-size: 30px">
              अखिल भारतीय इतिहास संकलन योजना कानपुर, बुन्देलखण्ड
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center">
      <div class="container d-flex align-items-center">
        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
            <li><a class="nav-link scrollto" href="#about">About</a></li>
            <li><a class="nav-link scrollto" href="#journal">Journal</a></li>
            <li>
              <a class="nav-link scrollto" href="#portfolio">Portfolio</a>
            </li>
            <li>
              <a class="nav-link" href="managingcommitee.php">Managing Committee</a>
            </li>
            <li class="dropdown">
              <a href="#"
                ><span>Journal</span> <i class="bi bi-chevron-down"></i
              ></a>
              <ul>
               <!-- <li><a href="#">Journal</a></li>
                 <li class="dropdown">
                  <a href="journal.php"
                    ><span>Deep Drop Down</span>
                    <i class="bi bi-chevron-right" style="background-color:blue;"></i
                  ></a>
                  <ul>
                    <li><a href="#">Deep Drop Down 1</a></li>
                    <li><a href="#">Deep Drop Down 2</a></li>
                  </ul>
                </li> -->
                <li><a href="journal.php">About the Journal</a></li>
                <li><a href="editorial.php">Editorial Board</a></li>
                <li><a href="authors.php">For Authors</a></li>
                <li><a href="ethicdiscc.php">Ethisc Discussion</a></li>
                <li><a href="allvolume.php">All Volume & Issues</a></li>
              </ul>
            </li>
            <li><a class="nav-link scrollto" href="#team">Team</a></li>
            
            <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
        <!-- .navbar -->
      </div>
    </header>
    <!-- End Header -->

    <!-- ======= Hero Section ======= -->
    <section id="hero">
      <div
        id="heroCarousel"
        data-bs-interval="5000"
        class="carousel slide carousel-fade"
        data-bs-ride="carousel"
      >
        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">
          <!-- Slide 1 -->
          <div
            class="carousel-item active"
            style="background-image: url(assets/img/slide/group.jpg)"
          >
            <div class="carousel-container">
              <div class="container">
                <h2 class="animate__animated animate__fadeInDown">
                  Welcome to <span>All India History Compilation Scheme Kanpur Bundelkhand</span>
                </h2>
                <p class="animate__animated animate__fadeInUp">
                  We are helping to save his culture.
                </p>
                <a
                  href="#about"
                  class="btn-get-started animate__animated animate__fadeInUp scrollto"
                  >Read More</a
                >
              </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div
            class="carousel-item"
            style="background-image: url(assets/img/slide/group.jpg)"
          >
            <div class="carousel-container">
              <div class="container">
                <h2 class="animate__animated animate__fadeInDown">
                  About All India History Compilation Scheme Kanpur Bundelkhand
                </h2>
                <p class="animate__animated animate__fadeInUp">
                  All India History Compilation Scheme Kanpur Bundelkhand is best culture org.
                </p>
                <a
                  href="#about"
                  class="btn-get-started animate__animated animate__fadeInUp scrollto"
                  >Read More</a
                >
              </div>
            </div>
          </div>
        </div>

        <a
          class="carousel-control-prev"
          href="#heroCarousel"
          role="button"
          data-bs-slide="prev"
        >
          <span
            class="carousel-control-prev-icon bi bi-chevron-left"
            aria-hidden="true"
          ></span>
        </a>

        <a
          class="carousel-control-next"
          href="#heroCarousel"
          role="button"
          data-bs-slide="next"
        >
          <span
            class="carousel-control-next-icon bi bi-chevron-right"
            aria-hidden="true"
          ></span>
        </a>
      </div>
    </section>
    <!-- End Hero -->

    <main id="main">
      <!-- ======= About Us Section ======= -->
      <section id="about" class="about">
        <div class="container">
          <div class="section-title mt-5">
            <h2>About Us</h2>
            <h5>
              All India History Compilation Scheme is a nationwide organization of scholars working in the field of History,
               Archaeology, Indology, Numismatics, Epigraphy, Law, modernity, Hindutva and other allied disciplines. 
               which is working in the direction of authentic, factual and allround history writing and publication
                in the field of History, Culture, traditions along with the various regional and micro level elements responsible for the creation of nation. 
            </h5>
            <h5>
              Scholars of History and Archeology residing in India and abroad.
                Scientists, Professors and scholars from Universities, Colleges and other 
                research centers working in scintific fields are associated with this work
                due to their respective taste and passion towards history and culture.
            
            </h5>
          </div>

          <div class="row">
            <div class="col-lg-6 order-1 order-lg-1">
              <img src="assets/img/group.jpg" class="img-fluid" alt="" />
            </div>
            <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-2 content">
              <ul>
                <li>
                <i class="bi bi-check-circled"></i>In 1973 'Baba Saheb Apte Memorial Committee' was established in 
                Nagpur with the inspiration of Shri Moreshwar Neelkanth Pingale (1919-2003),. Initially this committee took two tasks in its hands- <br>
                1. Propagation of the world's oldest language, Sanskrit, which is also called the mother of all the languages of the world. <br>
                2. Rewriting of Indian history and compilation of material for its purpose.
                </li>
                <li>
                <i class="bi bi-check-circled"></i>Akhil Bhartiya Itihas Sanklan Yojna has got expansion through all regions in India.
                  In similar manner the provincial unit was raised in Kanpur Bundelkhand region in nintees. Kanpur Bundelkhand Unit is
                  successfully functioning in capacity of non profit orbanisation and scholarly contributing in academic national nuilding.
                  </li>
                  Presently Dr. Bal Mukund Pandey ji Organisation
                  Secretary at national level as well as Sri Sanjay Shrigarsha Mishra ji Deputy organisational Secretary of organisation and Kanpur Bundelkhand 
                  Unit is aiming towards respective targets under the patronage of both philosophers.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <!-- End About Us Section -->

      <!-- ======= Journal Section ======= -->
      <section id="journal" class="journal mt-5">
        <div class="container">
          <div class="section-title">
            <h2>Our Journal</h2>
            <p>
              All the journals are highly regarded through South Asia and held to the highest standards to academic excellence....
            </p>
          </div>

          <div class="row">
            <div
              class="col-lg-6 col-md-6 d-flex align-items-stretch"
              data-aos="zoom-in"
              data-aos-delay="100"
            >
              <div class="iconbox-blue">
                <div class="card">
                <img src="assets/img/journal/gold.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Kanpur Historiographers</h5>
                  <p class="card-text">ISSN 2348-3814 is an internationally peer reviewed, refereed & indexed journal….</p>
                  <a href="#" class="btn btn-primary">learn more</a>
                </div>
              </div>
              </div>
            </div>

            <!-- <div
              class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0"
              data-aos="zoom-in"
              data-aos-delay="200"
            >
              <div class="icon-box iconbox-orange">
                <div class="icon">
                  <svg
                    width="100"
                    height="100"
                    viewBox="0 0 600 600"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      stroke="none"
                      stroke-width="0"
                      fill="#f5f5f5"
                      d="M300,582.0697525312426C382.5290701553225,586.8405444964366,449.9789794690241,525.3245884688669,502.5850820975895,461.55621195738473C556.606425686781,396.0723002908107,615.8543463187945,314.28637112970534,586.6730223649479,234.56875336149918C558.9533121215079,158.8439757836574,454.9685369536778,164.00468322053177,381.49747125262974,130.76875717737553C312.15926192815925,99.40240125094834,248.97055460311594,18.661163978235184,179.8680185752513,50.54337015887873C110.5421016452524,82.52863877960104,119.82277516462835,180.83849132639028,109.12597500060166,256.43424936330496C100.08760227029461,320.3096726198365,92.17705696193138,384.0621239912766,124.79988738764834,439.7174275375508C164.83382741302287,508.01625554203684,220.96474134820875,577.5009287672846,300,582.0697525312426"
                    ></path>
                  </svg>
                  <i class="bx bx-file"></i>
                </div>
                <h4><a href="">Sed Perspiciatis</a></h4>
                <p>
                  Duis aute irure dolor in reprehenderit in voluptate velit esse
                  cillum dolore
                </p>
              </div>
            </div> -->

            <div
              class="col-lg-6 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0"
              data-aos="zoom-in"
              data-aos-delay="300"
            >
              <div class="iconbox-blue">
                <div class="card">
                <img src="assets/img/journal/philosophers.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Kanpur Philosophers</h5>
                  <p class="card-text">ISSN 2348-3814 is an internationally peer reviewed, refereed & indexed journal….</p>
                  <a href="#" class="btn btn-primary">learn more</a>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- End Journal Section -->

    

      <!-- ======= Portfolio Section ======= -->
      <section id="portfolio" class="portfolio mt-5">
        <div class="container">
          <div class="section-title">
            <h2>Our Portfolio</h2>
            <p>
              Our lates portfolio.
            </p>
          </div>

          <div class="row">
            <div class="col-lg-12 d-flex justify-content-center">
              <ul id="portfolio-flters">
                <li data-filter="*" class="filter-active">All</li>
                <li data-filter=".filter-app">Journal</li>
                <li data-filter=".filter-card">History</li>
                <li data-filter=".filter-web">Philosophers</li>
              </ul>
            </div>
          </div>

          <div class="row portfolio-container">
            <div class="col-lg-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/journal/gold.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Gold</h4>
                  <p>Images</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/journal/gold.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="App 1"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-web">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/journal/philosophers.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Philosophers</h4>
                  <p>History</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/journal/philosophers.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="Web 3"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/slide/group.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Group</h4>
                  <p>Team</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/portfolio/portfolio-3.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="App 2"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-card">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/journal/philosophers.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>New Details</h4>
                  <p>Card</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/journal/philosophers.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="Card 2"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-web">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/portfolio/portfolio-5.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Web 2</h4>
                  <p>Web</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/portfolio/portfolio-5.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="Web 2"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/portfolio/portfolio-6.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>App 3</h4>
                  <p>App</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/portfolio/portfolio-6.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="App 3"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-card">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/portfolio/portfolio-7.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Card 1</h4>
                  <p>Card</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/portfolio/portfolio-7.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="Card 1"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-card">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/portfolio/portfolio-8.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Card 3</h4>
                  <p>Card</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/portfolio/portfolio-8.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="Card 3"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-web">
              <div class="portfolio-wrap">
                <img
                  src="assets/img/portfolio/portfolio-9.jpg"
                  class="img-fluid"
                  alt=""
                />
                <div class="portfolio-info">
                  <h4>Web 3</h4>
                  <p>Web</p>
                  <div class="portfolio-links">
                    <a
                      href="assets/img/portfolio/portfolio-9.jpg"
                      data-gallery="portfolioGallery"
                      class="portfolio-lightbox"
                      title="Web 3"
                      ><i class="bx bx-plus"></i
                    ></a>
                    <a href="#" title="More Details"
                      ><i class="bx bx-link"></i
                    ></a>
                  </div>
                </div>
              </div>
            </div> -->
          </div>
        </div>
      </section>
      <!-- End Portfolio Section -->

      <!-- ======= Team Section ======= -->
      <section id="team" class="team section-bg">
        <div class="container">
          <div class="section-title">
            <h2>Team</h2>
            <p>
              Supportive Team to create a adventure...
            </p>
          </div>

          <div class="row">
            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="member">
                <img src="assets/img/team/1.jpg" alt="" />
                <h4>Atul Kumar Shukla</h4>
                <span>Chief Executive Officer</span>
                <p>
                  Pt. Jwahar Lal.Nehru PG  College Banda  India
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="member">
                <img src="assets/img/team/2.jpg" alt="" />
                <h4>Dr. J. Shunmugaraja </h4>
                <span>Associate Editors & Referees</span>
                <p>
                  Maharaj Balwant Singh PG College Varanasi India
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="member">
                <img src="assets/img/team/3.jpg" alt="" />
                <h4>Prof. Purushottam Singh</h4>
                <span> Managing   Editor</span>
                <p>
                  Maharaj Balwant Singh PG College Varanasi India
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- End Team Section -->

      <!-- ======= Contact Section ======= -->
      <section id="contact" class="contact">
        <div class="container">
          <div class="section-title">
            <h2>Contact</h2>
            <p>
              Fill the form more details...
            </p>
          </div>

          <div class="row">
            <div class="col-lg-5 d-flex align-items-stretch">
              <div class="info">
                <div class="address">
                  <i class="bi bi-geo-alt"></i>
                  <h4>Location:</h4>
                  <p>A108 Adam Street, New York, NY 535022</p>
                </div>

                <div class="email">
                  <i class="bi bi-envelope"></i>
                  <h4>Email:</h4>
                  <p>info@example.com</p>
                </div>

                <div class="phone">
                  <i class="bi bi-phone"></i>
                  <h4>Call:</h4>
                  <p>+1 5589 55488 55s</p>
                </div>

                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621"
                  frameborder="0"
                  style="border: 0; width: 100%; height: 290px"
                  allowfullscreen
                ></iframe>
              </div>
            </div>

            <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
              <form
                action="forms/contact.php"
                method="post"
                role="form"
                class="php-email-form"
              >
                <div class="row">
                  <div class="form-group col-md-6">
                    <label for="name">Your Name</label>
                    <input
                      type="text"
                      name="name"
                      class="form-control"
                      id="name"
                      required
                    />
                  </div>
                  <div class="form-group col-md-6 mt-3 mt-md-0">
                    <label for="name">Your Email</label>
                    <input
                      type="email"
                      class="form-control"
                      name="email"
                      id="email"
                      required
                    />
                  </div>
                </div>
                <div class="form-group mt-3">
                  <label for="name">Subject</label>
                  <input
                    type="text"
                    class="form-control"
                    name="subject"
                    id="subject"
                    required
                  />
                </div>
                <div class="form-group mt-3">
                  <label for="name">Message</label>
                  <textarea
                    class="form-control"
                    name="message"
                    rows="10"
                    required
                  ></textarea>
                </div>
                <div class="my-3">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">
                    Your message has been sent. Thank you!
                  </div>
                </div>
                <div class="text-center">
                  <button type="submit">Send Message</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
      <!-- End Contact Section -->
    </main>
    <!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <div class="footer-logo">
                  <h5><span>All India History Compilation Scheme Kanpur Bundelkhand</span></h5>
                </div>
                <p>All India History Compilation Scheme is a nationwide organization of scholars working in the field of History,
                  Archaeology, Indology, Numismatics, Epigraphy, Law, modernity, Hindutva and other allied disciplines. 
                </p>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>Links</h4>
                <li><a href="#about">About</a></li>
                <li><a href="journal.html">Journal</a></li>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>Contact</h4>
                <div class="footer-contacts">
                  <p><span>Tel:</span> +123 456 789</p>
                  <p><span>Email:</span> contact@example.com</p>
                  <p><span>Working Hours:</span> 9am-5pm</p>
                </div>
              </div>
            </div>
          </div>
        <div class="social-links">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
        <div class="copyright">
          &copy; Copyright <strong><span>All India History Compilation Scheme Kanpur Bundelkhand </span>2023</strong>. All Rights Reserved
        </div>
      </div>
    </footer>
    <!-- End Footer -->

    <a
      href="#"
      class="back-to-top d-flex align-items-center justify-content-center"
      ><i class="bi bi-arrow-up-short"></i
    ></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
  </body>
</html>
